from django.apps import AppConfig


class TitleConfig(AppConfig):
    name = 'title'
